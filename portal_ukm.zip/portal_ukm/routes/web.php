<?php

use Illuminate\Support\Facades\Route;


Route::resources('/beranda', 'berandaController');
Route::resources('/login', 'logindaftarController');
Route::resources('/daftar', 'logindaftarController');
Route::resources('/setelahlogin', 'setelahloginController');