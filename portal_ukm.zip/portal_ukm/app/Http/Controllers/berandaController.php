<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class berandaController extends Controller
{
    public function index()
    {
        $beranda = beranda::all();
        return view('beranda.index');
    }
}
