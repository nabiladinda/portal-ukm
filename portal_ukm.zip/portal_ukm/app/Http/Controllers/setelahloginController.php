<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class setelahloginController extends Controller
{
    public function index()
    {
        $setelahlogin = setelahlogin::all();
        return view('setelahlogin.index');
    }
}
