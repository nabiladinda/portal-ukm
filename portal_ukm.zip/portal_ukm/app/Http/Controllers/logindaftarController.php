<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class logindaftarController extends Controller
{
    public function index()
    {
        $logindaftar = logindaftar::all();
        return view('logindaftar.index');
    }
}

